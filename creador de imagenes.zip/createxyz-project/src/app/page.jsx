"use client";
import React from "react";

function MainComponent() {
  const [prompt, setPrompt] = useState("");
  const [generatedImage, setGeneratedImage] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");
  const generateImage = async () => {
    if (!prompt.trim()) {
      setError("Por favor ingrese una descripción para generar la imagen");
      return;
    }

    setIsLoading(true);
    setError("");
    setGeneratedImage([]);

    try {
      const promises = Array.from({ length: 4 })
        .fill()
        .map(() =>
          fetch(
            `/integrations/stable-diffusion-v-3/?prompt=${encodeURIComponent(
              prompt
            )}`,
            {
              method: "GET",
            }
          )
        );

      const responses = await Promise.all(promises);
      const results = await Promise.all(
        responses.map(async (response) => {
          if (!response.ok) {
            throw new Error(`Error del servidor: ${response.status}`);
          }
          const data = await response.json();
          return data.data[0];
        })
      );

      setGeneratedImage(results);
    } catch (err) {
      setError(
        "No se pudieron generar las imágenes. Por favor, intente nuevamente."
      );
      console.error("Error generando imágenes:", err);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#050505] relative p-4 md:p-8">
      <div className="absolute inset-0 bg-[#111111] bg-grid-small-white/[0.2] -z-10" />
      <div className="absolute inset-0 bg-gradient-to-t from-[#050505] via-transparent to-transparent -z-10" />

      <div className="max-w-4xl mx-auto">
        <div className="pt-4 md:pt-8">
          <h1 className="text-2xl md:text-4xl font-bold text-center mb-2 text-[#00ffff] font-inter neon-text">
            GENERADOR DE IMÁGENES CON IA
          </h1>
          <p className="text-gray-400 text-center mb-8 font-inter">
            Describe lo que deseas crear y la IA lo generará
          </p>
        </div>

        <div className="backdrop-blur-sm bg-black/30 rounded-2xl p-6 md:p-8 border border-[#00ffff]/20 neon-box">
          <textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            className="w-full h-32 bg-black/50 text-[#98ff98] rounded-xl p-4 border border-[#00ffff]/30 focus:border-[#00ffff] transition-all duration-300 outline-none resize-none font-inter neon-input"
            placeholder="Describe la imagen que deseas generar (sé específico)..."
            disabled={isLoading}
          />
          <div className="flex flex-col md:flex-row gap-4 mt-4">
            <button
              onClick={generateImage}
              disabled={isLoading || !prompt.trim()}
              className="flex-1 px-8 py-4 bg-transparent border-2 border-[#00ffff] text-[#00ffff] rounded-xl font-bold transition-all duration-300 hover:bg-[#00ffff]/5 hover:shadow-[0_0_20px_rgba(0,255,255,0.5)] disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:bg-transparent font-inter neon-button"
            >
              {isLoading ? (
                <span className="flex items-center justify-center">
                  <svg
                    className="animate-spin -ml-1 mr-3 h-5 w-5 text-[#00ffff]"
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 24 24"
                  >
                    <circle
                      className="opacity-25"
                      cx="12"
                      cy="12"
                      r="10"
                      stroke="currentColor"
                      strokeWidth="4"
                    ></circle>
                    <path
                      className="opacity-75"
                      fill="currentColor"
                      d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                    ></path>
                  </svg>
                  Generando...
                </span>
              ) : (
                "Generar Imágenes con IA"
              )}
            </button>
          </div>

          {error && (
            <div className="mt-4 text-[#ff4444] bg-[#ff444420] p-4 rounded-xl border border-[#ff4444]/30 font-inter">
              <p>{error}</p>
              <p className="text-sm mt-2">
                Sugerencia: Intenta ser más específico en tu descripción. Por
                ejemplo: "Un gato siamés jugando con un ovillo de lana azul,
                estilo realista"
              </p>
            </div>
          )}

          <div className="mt-8">
            {isLoading ? (
              <div className="grid grid-cols-2 gap-4">
                {[...Array.from({ length: 4 })].map((_, index) => (
                  <div
                    key={index}
                    className="animate-pulse bg-black/50 rounded-xl aspect-square flex items-center justify-center border border-[#00ffff]/20"
                  >
                    <div className="text-[#00ffff]">
                      <svg className="animate-spin h-8 w-8" viewBox="0 0 24 24">
                        <circle
                          className="opacity-25"
                          cx="12"
                          cy="12"
                          r="10"
                          stroke="currentColor"
                          strokeWidth="4"
                          fill="none"
                        />
                        <path
                          className="opacity-75"
                          fill="currentColor"
                          d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                        />
                      </svg>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-4">
                {generatedImage.map((imgUrl, index) => (
                  <div
                    key={index}
                    className="relative group transition-all duration-300"
                  >
                    <img
                      src={imgUrl}
                      alt={`Imagen generada ${index + 1}`}
                      className="rounded-xl w-full aspect-square object-cover shadow-lg transition-all duration-300 group-hover:scale-[1.01] border border-[#00ffff]/20"
                    />
                    <div className="absolute inset-0 rounded-xl bg-gradient-to-t from-[#00ffff20] to-transparent opacity-0 group-hover:opacity-100 transition-all duration-300"></div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      <style jsx global>{`
        .bg-grid-small-white {
          background-size: 30px 30px;
          background-image: linear-gradient(to right, #222 1px, transparent 1px),
            linear-gradient(to bottom, #222 1px, transparent 1px);
        }

        @keyframes neonFlicker {
          0%, 100% { 
            text-shadow: 0 0 10px #00ffff80,
                         0 0 20px #00ffff50,
                         0 0 30px #00ffff30;
          }
          50% { 
            text-shadow: 0 0 15px #00ffff90,
                         0 0 25px #00ffff60,
                         0 0 35px #00ffff40;
          }
        }

        .neon-text {
          animation: neonFlicker 3s infinite;
        }

        .neon-box {
          box-shadow: 0 0 10px #00ffff20,
                     inset 0 0 20px #00ffff10;
        }

        .neon-input:focus {
          box-shadow: 0 0 10px #00ffff40,
                     inset 0 0 10px #00ffff20;
        }

        .neon-button {
          box-shadow: 0 0 10px #00ffff20;
          transition: all 0.3s ease;
        }

        .neon-button:hover:not(:disabled) {
          box-shadow: 0 0 15px #00ffff40,
                     0 0 30px #00ffff20;
          text-shadow: 0 0 8px #00ffff;
        }

        @keyframes glow {
          0% { box-shadow: 0 0 5px #00ffff40; }
          50% { box-shadow: 0 0 20px #00ffff40, 0 0 30px #00ffff20; }
          100% { box-shadow: 0 0 5px #00ffff40; }
        }
      `}</style>
    </div>
  );
}

export default MainComponent;